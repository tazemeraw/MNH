import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get(api.surveys.list.path, async (req, res) => {
    const surveys = await storage.getSurveys();
    res.json(surveys);
  });

  app.get(api.surveys.get.path, async (req, res) => {
    const survey = await storage.getSurvey(Number(req.params.id));
    if (!survey) {
      return res.status(404).json({ message: 'Survey not found' });
    }
    res.json(survey);
  });

  app.post(api.surveys.create.path, async (req, res) => {
    try {
      const input = api.surveys.create.input.parse(req.body);
      const survey = await storage.createSurvey(input);
      res.status(201).json(survey);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.patch(api.surveys.update?.path || '/api/surveys/:id', async (req, res) => {
    try {
      const id = Number(req.params.id);
      const survey = await storage.getSurvey(id);
      if (!survey) {
        return res.status(404).json({ message: 'Survey not found' });
      }
      const { data } = req.body;
      if (!data) {
        return res.status(400).json({ message: 'Data field is required' });
      }
      const updated = await storage.updateSurvey(id, { data });
      res.json(updated);
    } catch (err) {
      console.error('Update error:', err);
      res.status(500).json({ message: 'Failed to update survey' });
    }
  });

  app.delete(api.surveys.delete.path, async (req, res) => {
    const survey = await storage.getSurvey(Number(req.params.id));
    if (!survey) {
      return res.status(404).json({ message: 'Survey not found' });
    }
    await storage.deleteSurvey(Number(req.params.id));
    res.status(204).send();
  });

  // Seed data
  const existing = await storage.getSurveys();
  if (existing.length === 0) {
    console.log("Seeding initial survey data...");
    await storage.createSurvey({
      data: {
        facility_identification: {
          facility_name: "St. Paul's Hospital Millennium Medical College",
          region: "Addis Ababa",
          zone: "Gullele",
          woreda: "Woreda 9",
          phcu_name: "St. Paul PHCU",
          facility_type: "Specialized Hospital"
        },
        staffing: {
          number_of_midwives: "45",
          number_of_nurses: "120",
          number_of_doctors: "35",
          number_of_health_officers: "10"
        },
        maternal_health_services: {
          anc_service_available: true,
          delivery_service_available: true,
          pnc_service_available: true,
          c_section_available: true
        },
        status: "Completed",
        respondent_name: "Dr. Abebe Kebede",
        date: new Date().toISOString()
      }
    });
    
    await storage.createSurvey({
      data: {
        facility_identification: {
          facility_name: "Adama General Hospital",
          region: "Oromia",
          zone: "East Shewa",
          woreda: "Adama",
          phcu_name: "Adama PHCU",
          facility_type: "General Hospital"
        },
        staffing: {
          number_of_midwives: "25",
          number_of_nurses: "80",
          number_of_doctors: "15",
          number_of_health_officers: "8"
        },
        maternal_health_services: {
          anc_service_available: true,
          delivery_service_available: true,
          pnc_service_available: true,
          c_section_available: true
        },
        status: "In Progress",
        respondent_name: "Sr. Tigist Alene",
        date: new Date(Date.now() - 86400000).toISOString() // Yesterday
      }
    });
  }

  return httpServer;
}
