## Packages
react-hook-form | Form state management
@hookform/resolvers | Validation resolvers for react-hook-form
zod | Schema validation
framer-motion | Smooth animations for steps and transitions
date-fns | Date formatting

## Notes
The survey form is complex and requires managing a large JSON object.
We will use react-hook-form with a Zod schema that matches the expected JSON structure.
The form is broken down into steps for better UX.
Data persistence is handled by sending the entire JSON blob to the backend.
