import { useState, useMemo } from "react";
import { Link, useLocation } from "wouter";
import { useSurveys, useDeleteSurvey } from "@/hooks/use-surveys";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Loader2,
  Trash2,
  Eye,
  Plus,
  Search,
  MapPin,
  Calendar,
  Building2,
  Download,
  LogOut,
  BarChart3,
  TrendingUp,
  Users,
  Edit,
  X,
} from "lucide-react";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area, ComposedChart } from "recharts";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { data: surveys, isLoading, error, refetch } = useSurveys();
  const deleteSurvey = useDeleteSurvey();
  const { toast } = useToast();

  const [search, setSearch] = useState("");
  const [selectedSurvey, setSelectedSurvey] = useState<any | null>(null);
  const [editingSurvey, setEditingSurvey] = useState<any | null>(null);
  const [viewMode, setViewMode] = useState<"grid" | "analytics">("grid");

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this record? This cannot be undone.")) {
      try {
        await deleteSurvey.mutateAsync(id);
        toast({ title: "Deleted", description: "Survey record removed." });
        refetch();
      } catch (e) {
        toast({ title: "Error", description: "Failed to delete survey.", variant: "destructive" });
      }
    }
  };

  const handleDownload = (survey: any) => {
    const dataStr = JSON.stringify(survey.data, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `survey-${survey.id}-${format(new Date(), "yyyy-MM-dd")}.json`;
    link.click();
    toast({ title: "Downloaded", description: "Survey data exported as JSON" });
  };

  const handleDownloadAll = () => {
    if (!surveys || surveys.length === 0) {
      toast({ title: "No Data", description: "No surveys to download" });
      return;
    }
    const allData = surveys.map(s => ({ id: s.id, createdAt: s.createdAt, ...s.data }));
    const dataStr = JSON.stringify(allData, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `all-surveys-${format(new Date(), "yyyy-MM-dd")}.json`;
    link.click();
    toast({ title: "Downloaded", description: `All ${surveys.length} survey records exported as JSON` });
  };

  const handleSaveEdit = async () => {
    if (!editingSurvey) return;
    try {
      const response = await fetch(`/api/surveys/${editingSurvey.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ data: editingSurvey.data }),
      });
      if (response.ok) {
        toast({ title: "Updated", description: "Survey record updated successfully." });
        setEditingSurvey(null);
        refetch();
      }
    } catch (e) {
      toast({ title: "Error", description: "Failed to update survey.", variant: "destructive" });
    }
  };

  const handleLogout = () => {
    setLocation("/");
    toast({ title: "Logged Out", description: "You have been logged out." });
  };

  const filteredSurveys = surveys?.filter((s) => {
    const data = s.data as any;
    const term = search.toLowerCase();
    return (
      data.facilityName?.toLowerCase().includes(term) ||
      data.region?.toLowerCase().includes(term) ||
      data.woreda?.toLowerCase().includes(term)
    );
  });

  // Analytics calculations
  const analytics = useMemo(() => {
    if (!surveys || surveys.length === 0) {
      return { 
        byRegion: [], 
        staffingStats: [], 
        serviceStats: [], 
        infrastructureStats: [],
        trendData: [],
        facilityTypeStats: [],
        readinessScores: [],
        complianceMetrics: []
      };
    }

    const regionMap: Record<string, any> = {};
    const facilityTypeMap: Record<string, number> = {};
    let totalMidwives = 0;
    let facilitiesWithElectricity = 0;
    let facilitiesWithWater = 0;
    let facilitiesWithAntental = 0;
    let facilitiesWithDelivery = 0;
    let facilitiesWithPostnatal = 0;
    let totalWithCompleteServices = 0;

    surveys.forEach((survey) => {
      const data = survey.data as any;
      const region = data.region || "Unknown";

      if (!regionMap[region]) {
        regionMap[region] = { region, count: 0, midwives: 0, obgyns: 0, electricity: 0, water: 0, readiness: 0 };
      }

      regionMap[region].count += 1;
      if (data.hasMidwife) regionMap[region].midwives += data.midwifeCount || 1;
      if (data.hasObGyn) regionMap[region].obgyns += data.obGynCount || 1;
      if (data.hasElectricity) regionMap[region].electricity += 1;
      if (data.hasWater) regionMap[region].water += 1;

      // Calculate readiness score
      let readinessScore = 0;
      if (data.hasElectricity) readinessScore += 25;
      if (data.hasWater) readinessScore += 25;
      if (data.hasMidwife) readinessScore += 25;
      if (data.offersDelivery) readinessScore += 25;
      regionMap[region].readiness = (regionMap[region].readiness + readinessScore) / regionMap[region].count;

      totalMidwives += data.midwifeCount || 0;
      if (data.hasElectricity) facilitiesWithElectricity += 1;
      if (data.hasWater) facilitiesWithWater += 1;
      if (data.offersAntenatalCare) facilitiesWithAntental += 1;
      if (data.offersDelivery) facilitiesWithDelivery += 1;
      if (data.offersPostnatalCare) facilitiesWithPostnatal += 1;
      
      if (data.offersAntenatalCare && data.offersDelivery && data.offersPostnatalCare) {
        totalWithCompleteServices += 1;
      }

      facilityTypeMap[data.facilityType || "Unknown"] = (facilityTypeMap[data.facilityType || "Unknown"] || 0) + 1;
    });

    const byRegion = Object.values(regionMap).sort((a, b) => b.count - a.count);
    
    const staffingStats = [
      { name: "Midwives", value: totalMidwives },
      { name: "Health Workers", value: surveys.length },
    ];
    
    const infraStats = [
      { name: "Electricity", value: facilitiesWithElectricity, color: "#3b82f6" },
      { name: "Water Supply", value: facilitiesWithWater, color: "#10b981" },
      { name: "No Services", value: surveys.length - Math.max(facilitiesWithElectricity, facilitiesWithWater), color: "#ef4444" },
    ];

    const facilityTypeStats = Object.entries(facilityTypeMap).map(([type, count]) => ({
      name: type,
      value: count,
      percentage: Math.round((count / surveys.length) * 100),
    }));

    const trendData = byRegion.map(r => ({
      region: r.region.substring(0, 10),
      facilities: r.count,
      readiness: Math.round(r.readiness),
      infrastructure: r.electricity + r.water,
    }));

    return {
      byRegion,
      staffingStats,
      serviceStats: [
        { name: "Antenatal Care", value: facilitiesWithAntental },
        { name: "Delivery Services", value: facilitiesWithDelivery },
        { name: "Postnatal Care", value: facilitiesWithPostnatal },
        { name: "Complete Services", value: totalWithCompleteServices },
      ],
      infrastructureStats: infraStats,
      facilityTypeStats,
      trendData,
      complianceMetrics: [
        { name: "Complete Service", value: Math.round((totalWithCompleteServices / surveys.length) * 100) },
        { name: "Infrastructure Ready", value: Math.round((facilitiesWithElectricity / surveys.length) * 100) },
        { name: "Staffed with Midwife", value: Math.round((surveys.filter(s => (s.data as any).hasMidwife).length / surveys.length) * 100) },
      ],
    };
  }, [surveys]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Navbar */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-3 cursor-pointer">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white font-bold">
                M
              </div>
              <div>
                <div className="font-bold text-lg text-gray-900">MNH Dashboard</div>
                <div className="text-xs text-gray-500">Admin Portal</div>
              </div>
            </div>
          </Link>
          <div className="flex gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownloadAll}
              className="text-green-700 hover:bg-green-100"
              data-testid="button-download-all"
            >
              <Download className="h-4 w-4 mr-2" /> Download All
            </Button>
            <Button variant="ghost" size="sm" onClick={handleLogout} data-testid="button-logout">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Stats Cards */}
        {!isLoading && surveys && surveys.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Total Facilities</p>
                  <p className="text-3xl font-bold text-gray-900 mt-1">{surveys.length}</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600">
                  <Building2 className="h-6 w-6" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Regions Covered</p>
                  <p className="text-3xl font-bold text-gray-900 mt-1">{analytics.byRegion.length}</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-600">
                  <MapPin className="h-6 w-6" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Total Midwives</p>
                  <p className="text-3xl font-bold text-gray-900 mt-1">
                    {surveys.reduce((sum, s) => sum + ((s.data as any).midwifeCount || 0), 0)}
                  </p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center text-purple-600">
                  <Users className="h-6 w-6" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Complete Services</p>
                  <p className="text-3xl font-bold text-green-600 mt-1">
                    {surveys.filter(s => {
                      const d = s.data as any;
                      return d.offersAntenatalCare && d.offersDelivery && d.offersPostnatalCare;
                    }).length}
                  </p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center text-green-600">
                  <TrendingUp className="h-6 w-6" />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* View Toggle */}
        <div className="flex gap-2 mb-6">
          <Button
            variant={viewMode === "grid" ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode("grid")}
            className={viewMode === "grid" ? "bg-gradient-to-r from-blue-600 to-indigo-600" : ""}
          >
            <Building2 className="h-4 w-4 mr-2" /> Records
          </Button>
          <Button
            variant={viewMode === "analytics" ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode("analytics")}
            className={viewMode === "analytics" ? "bg-gradient-to-r from-blue-600 to-indigo-600" : ""}
          >
            <BarChart3 className="h-4 w-4 mr-2" /> Analytics
          </Button>
        </div>

        {/* Grid View */}
        {viewMode === "grid" && (
          <>
            {/* Search */}
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-4 top-3.5 h-4 w-4 text-gray-400" />
                <input
                  className="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-300 bg-white shadow-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all outline-none"
                  placeholder="Search by facility name, region, or woreda..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  data-testid="input-search"
                />
              </div>
            </div>

            {/* Content */}
            {isLoading ? (
              <div className="flex justify-center items-center h-64">
                <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
              </div>
            ) : error ? (
              <div className="p-8 text-center bg-red-50 rounded-2xl border border-red-200 text-red-600">
                Failed to load surveys. Please try again later.
              </div>
            ) : filteredSurveys?.length === 0 ? (
              <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-gray-300">
                <Building2 className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900">No surveys found</h3>
                <p className="text-gray-600 mb-6">Get started by creating a new assessment.</p>
                <Link href="/survey">
                  <Button variant="outline">Start Survey</Button>
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredSurveys?.map((survey) => {
                  const data = survey.data as any;
                  return (
                    <div
                      key={survey.id}
                      className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-lg hover:border-blue-200 transition-all duration-300 group"
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div className="p-2.5 bg-blue-100 rounded-lg text-blue-600 group-hover:bg-blue-200 transition-colors">
                          <Building2 className="h-5 w-5" />
                        </div>
                        <span className="text-xs font-semibold px-2.5 py-1 bg-gray-100 rounded-full text-gray-700">
                          ID: {survey.id}
                        </span>
                      </div>

                      <h3 className="text-lg font-bold text-gray-900 mb-1 line-clamp-1">
                        {data.facilityName || "Unnamed Facility"}
                      </h3>

                      <div className="space-y-2 mb-6">
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="h-3.5 w-3.5 mr-2 text-gray-400" />
                          {data.region}, {data.woreda}
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <Calendar className="h-3.5 w-3.5 mr-2 text-gray-400" />
                          {survey.createdAt ? format(new Date(survey.createdAt), "PPP") : "N/A"}
                        </div>
                      </div>

                      <div className="flex gap-2 pt-4 border-t border-gray-100">
                        <Button
                          size="sm"
                          className="flex-1 bg-blue-100 text-blue-700 hover:bg-blue-200 shadow-none"
                          onClick={() => setSelectedSurvey(survey)}
                          data-testid={`button-view-${survey.id}`}
                        >
                          <Eye className="mr-2 h-4 w-4" /> View
                        </Button>
                        <Button
                          size="sm"
                          className="flex-1 bg-amber-100 text-amber-700 hover:bg-amber-200 shadow-none"
                          onClick={() => setEditingSurvey(survey)}
                          data-testid={`button-edit-${survey.id}`}
                        >
                          <Edit className="mr-2 h-4 w-4" /> Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="flex-1 text-green-700 hover:bg-green-100"
                          onClick={() => handleDownload(survey)}
                          data-testid={`button-download-${survey.id}`}
                        >
                          <Download className="mr-2 h-4 w-4" /> Download
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-red-600 hover:text-red-700 hover:bg-red-100"
                          onClick={() => handleDelete(survey.id)}
                          disabled={deleteSurvey.isPending}
                          data-testid={`button-delete-${survey.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}

        {/* Analytics View */}
        {viewMode === "analytics" && surveys && surveys.length > 0 && (
          <div className="space-y-6">
            {/* Core Indicators */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {analytics.complianceMetrics.map((metric, idx) => (
                <div key={idx} className={`rounded-xl p-4 border text-white font-bold text-2xl`}
                  style={{
                    background: idx === 0 ? "linear-gradient(to br, #059669, #047857)" : idx === 1 ? "linear-gradient(to br, #0891b2, #0e7490)" : "linear-gradient(to br, #d97706, #b45309)",
                    borderColor: "transparent"
                  }}>
                  <p className="text-sm opacity-90 mb-1">{metric.name}</p>
                  <p>{metric.value}%</p>
                </div>
              ))}
            </div>

            {/* Charts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Facilities by Region */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Facilities by Region</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={analytics.byRegion}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="region" angle={-45} textAnchor="end" height={80} tick={{ fontSize: 12 }} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#3b82f6" name="Facilities" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Regional Readiness Trend */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Readiness Score by Region</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={analytics.trendData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="region" tick={{ fontSize: 12 }} />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="readiness" stroke="#10b981" strokeWidth={2} name="Readiness %" />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Service Coverage */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Service Coverage</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={analytics.serviceStats}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} tick={{ fontSize: 12 }} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#8b5cf6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Staffing Resources */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Staffing by Region</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <ComposedChart data={analytics.byRegion}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="region" angle={-45} textAnchor="end" height={80} tick={{ fontSize: 12 }} />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="midwives" fill="#10b981" name="Midwives" />
                    <Line type="monotone" dataKey="obgyns" stroke="#f59e0b" name="OB/GYN" />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>

              {/* Infrastructure Status */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Infrastructure Status</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={analytics.infrastructureStats}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {analytics.infrastructureStats.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Facility Type Distribution */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Facility Type Distribution</h3>
                <div className="space-y-3">
                  {analytics.facilityTypeStats.map((type, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium text-gray-700">{type.name}</span>
                        <span className="text-gray-600">{type.value} ({type.percentage}%)</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${type.percentage}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Regional Summary Table */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 lg:col-span-2">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Regional Analysis Summary</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="text-left py-3 px-3 font-semibold text-gray-700">Region</th>
                        <th className="text-center py-3 px-3 font-semibold text-gray-700">Facilities</th>
                        <th className="text-center py-3 px-3 font-semibold text-gray-700">Midwives</th>
                        <th className="text-center py-3 px-3 font-semibold text-gray-700">Infrastructure</th>
                        <th className="text-center py-3 px-3 font-semibold text-gray-700">Readiness</th>
                      </tr>
                    </thead>
                    <tbody>
                      {analytics.byRegion.map((region: any, idx) => (
                        <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="py-3 px-3 font-medium text-gray-900">{region.region}</td>
                          <td className="text-center py-3 px-3">{region.count}</td>
                          <td className="text-center py-3 px-3">{region.midwives}</td>
                          <td className="text-center py-3 px-3">
                            <span className="inline-flex items-center gap-1 text-xs">
                              <span className="w-2 h-2 rounded-full bg-blue-600"></span>{region.electricity}
                              <span className="w-2 h-2 rounded-full bg-green-600"></span>{region.water}
                            </span>
                          </td>
                          <td className="text-center py-3 px-3">
                            <span className="inline-flex items-center justify-center px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-semibold">
                              {Math.round(region.readiness)}%
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Details Modal */}
      <Dialog open={!!selectedSurvey} onOpenChange={(open) => !open && setSelectedSurvey(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Survey Details</DialogTitle>
          </DialogHeader>
          {selectedSurvey && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-gray-600">Facility Name:</span> {(selectedSurvey.data as any).facilityName}
                </div>
                <div>
                  <span className="text-gray-600">Type:</span> {(selectedSurvey.data as any).facilityType}
                </div>
                <div>
                  <span className="text-gray-600">Region:</span> {(selectedSurvey.data as any).region}
                </div>
                <div>
                  <span className="text-gray-600">Woreda:</span> {(selectedSurvey.data as any).woreda}
                </div>
              </div>
              <pre className="bg-gray-100 p-4 rounded-lg text-xs overflow-auto max-h-96">
                {JSON.stringify((selectedSurvey.data as any), null, 2)}
              </pre>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Modal */}
      <Dialog open={!!editingSurvey} onOpenChange={(open) => !open && setEditingSurvey(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Survey Record</DialogTitle>
          </DialogHeader>
          {editingSurvey && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium">Facility Name</label>
                  <Input
                    value={(editingSurvey.data as any).facilityName || ""}
                    onChange={(e) =>
                      setEditingSurvey({
                        ...editingSurvey,
                        data: { ...editingSurvey.data, facilityName: e.target.value },
                      })
                    }
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Region</label>
                  <Input
                    value={(editingSurvey.data as any).region || ""}
                    onChange={(e) =>
                      setEditingSurvey({
                        ...editingSurvey,
                        data: { ...editingSurvey.data, region: e.target.value },
                      })
                    }
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Woreda</label>
                  <Input
                    value={(editingSurvey.data as any).woreda || ""}
                    onChange={(e) =>
                      setEditingSurvey({
                        ...editingSurvey,
                        data: { ...editingSurvey.data, woreda: e.target.value },
                      })
                    }
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Facility Type</label>
                  <Input
                    value={(editingSurvey.data as any).facilityType || ""}
                    onChange={(e) =>
                      setEditingSurvey({
                        ...editingSurvey,
                        data: { ...editingSurvey.data, facilityType: e.target.value },
                      })
                    }
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={handleSaveEdit}
                  className="bg-blue-600 text-white hover:bg-blue-700"
                  data-testid="button-save-edit"
                >
                  Save Changes
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setEditingSurvey(null)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
