import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Survey() {
  return (
    <div style={{ width: "100%", height: "100vh", display: "flex", flexDirection: "column" }}>
      {/* Navigation Header */}
      <div style={{
        padding: "16px 24px",
        borderBottom: "1px solid #e5e7eb",
        backgroundColor: "white",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <div style={{
            width: "40px",
            height: "40px",
            borderRadius: "8px",
            background: "linear-gradient(to right, #2563eb, #4f46e5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "white",
            fontWeight: "bold"
          }}>
            M
          </div>
          <div>
            <div style={{ fontSize: "16px", fontWeight: "bold", color: "#111827" }}>MNH Survey</div>
            <div style={{ fontSize: "12px", color: "#6b7280" }}>Facility Assessment</div>
          </div>
        </div>
        <Link href="/">
          <Button variant="outline" size="sm" style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <ArrowLeft className="h-4 w-4" /> Back to Home
          </Button>
        </Link>
      </div>

      {/* Survey iframe */}
      <iframe
        src="/survey.html"
        style={{
          width: "100%",
          height: "calc(100vh - 73px)",
          border: "none",
          display: "block",
          margin: 0,
          padding: 0
        }}
        title="MNH Support Facility Survey"
      />
    </div>
  );
}
