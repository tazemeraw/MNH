import { Link } from "wouter";
import { ArrowRight, ClipboardList, Lock, BarChart3, Users, Building2, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Navbar */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white font-bold text-lg">
              M
            </div>
            <div>
              <div className="font-bold text-lg text-gray-900">MNH Survey</div>
              <div className="text-xs text-gray-500">Health Facility Assessment</div>
            </div>
          </div>
          <div className="flex gap-3">
            <Link href="/login">
              <Button variant="outline" className="border-gray-300 hover:border-gray-400">
                <Lock className="mr-2 h-4 w-4" /> Admin Login
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="flex-1 relative overflow-hidden">
        {/* Background decorations */}
        <div className="absolute inset-0">
          <div className="absolute top-20 right-20 w-72 h-72 bg-blue-200/20 rounded-full blur-3xl"></div>
          <div className="absolute -bottom-20 -left-20 w-96 h-96 bg-indigo-200/20 rounded-full blur-3xl"></div>
          <div className="absolute top-1/2 left-1/4 w-64 h-64 bg-purple-200/10 rounded-full blur-3xl"></div>
        </div>

        <main className="relative z-10 flex flex-col items-center justify-center px-4 sm:px-6 lg:px-8 min-h-[600px] text-center">
          <div className="max-w-4xl space-y-8 animate-in fade-in zoom-in duration-700 slide-in-from-bottom-8">
            {/* Badge */}
            <div className="inline-flex items-center rounded-full border border-blue-200 bg-blue-50 px-4 py-2 text-sm font-medium text-blue-700 backdrop-blur-sm">
              <span className="flex h-2 w-2 rounded-full bg-blue-600 mr-2 animate-pulse"></span>
              National Health Assessment 2024 - Survey System
            </div>

            {/* Main heading */}
            <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold tracking-tight text-gray-900 leading-tight">
              Maternal & Neonatal
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600">
                Health Support
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed font-light">
              Comprehensive facility assessment system designed to improve maternal care outcomes.
              Collect standardized data on staffing, infrastructure, and service readiness across
              health facilities in your region.
            </p>

            {/* Feature highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl mx-auto pt-4">
              <div className="flex flex-col items-center gap-2 text-sm">
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600">
                  <ClipboardList className="h-5 w-5" />
                </div>
                <span className="text-gray-700 font-medium">Easy Assessment</span>
              </div>
              <div className="flex flex-col items-center gap-2 text-sm">
                <div className="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-600">
                  <BarChart3 className="h-5 w-5" />
                </div>
                <span className="text-gray-700 font-medium">Data Analytics</span>
              </div>
              <div className="flex flex-col items-center gap-2 text-sm">
                <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center text-purple-600">
                  <Users className="h-5 w-5" />
                </div>
                <span className="text-gray-700 font-medium">Multi-User</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-8">
              <Link href="/user-login">
                <Button
                  size="lg"
                  className="h-14 px-8 text-lg shadow-xl shadow-blue-500/25 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transition-all"
                  data-testid="button-start-survey"
                >
                  <ClipboardList className="mr-3 h-5 w-5" /> Start New Assessment
                </Button>
              </Link>

              <Link href="/login">
                <Button
                  variant="outline"
                  size="lg"
                  className="h-14 px-8 text-lg rounded-xl border-2 border-gray-300 hover:border-gray-400 hover:bg-gray-50 transition-all"
                  data-testid="button-admin-login"
                >
                  <Lock className="mr-3 h-5 w-5" /> Admin Dashboard
                </Button>
              </Link>
            </div>
          </div>
        </main>
      </div>

      {/* Benefits Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Why Use Our Assessment System?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600 mb-4">
                <Building2 className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Facility Assessment</h3>
              <p className="text-gray-600">
                Comprehensive evaluation of staffing, infrastructure, and service capacity at health facilities.
              </p>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-600 mb-4">
                <BarChart3 className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Data Analytics</h3>
              <p className="text-gray-600">
                Real-time dashboards and analytics to track facility readiness across regions and districts.
              </p>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center text-purple-600 mb-4">
                <CheckCircle className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Quality Improvement</h3>
              <p className="text-gray-600">
                Identify gaps and plan targeted interventions to improve maternal and newborn health outcomes.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 py-8 text-center text-sm text-gray-600 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <p>&copy; 2024 MNH Support Facility. All rights reserved. | Advancing Maternal & Newborn Health</p>
        </div>
      </footer>
    </div>
  );
}
