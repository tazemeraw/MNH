import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type SurveyInput } from "@shared/routes";

// GET /api/surveys
export function useSurveys() {
  return useQuery({
    queryKey: [api.surveys.list.path],
    queryFn: async () => {
      const res = await fetch(api.surveys.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch surveys");
      return api.surveys.list.responses[200].parse(await res.json());
    },
  });
}

// GET /api/surveys/:id
export function useSurvey(id: number) {
  return useQuery({
    queryKey: [api.surveys.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.surveys.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch survey");
      return api.surveys.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

// POST /api/surveys
export function useCreateSurvey() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: SurveyInput) => {
      const validated = api.surveys.create.input.parse(data);
      const res = await fetch(api.surveys.create.path, {
        method: api.surveys.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.surveys.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to submit survey");
      }
      return api.surveys.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.surveys.list.path] }),
  });
}

// DELETE /api/surveys/:id
export function useDeleteSurvey() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.surveys.delete.path, { id });
      const res = await fetch(url, { 
        method: api.surveys.delete.method, 
        credentials: "include" 
      });
      if (res.status === 404) throw new Error("Survey not found");
      if (!res.ok) throw new Error("Failed to delete survey");
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.surveys.list.path] }),
  });
}
