import { useFormContext } from "react-hook-form";
import { cn } from "@/lib/utils";

interface FormInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  name: string;
  label: string;
  description?: string;
}

export function FormInput({ name, label, description, className, ...props }: FormInputProps) {
  const { register, formState: { errors } } = useFormContext();
  const error = errors[name]?.message as string | undefined;

  return (
    <div className="space-y-2">
      <label htmlFor={name} className="form-label">
        {label}
        {props.required && <span className="text-destructive ml-1">*</span>}
      </label>
      <input
        id={name}
        {...register(name, { valueAsNumber: props.type === 'number' })}
        className={cn(
          "form-input",
          error && "border-destructive focus-visible:ring-destructive",
          className
        )}
        {...props}
      />
      {description && <p className="text-xs text-muted-foreground">{description}</p>}
      {error && <p className="text-xs font-medium text-destructive">{error}</p>}
    </div>
  );
}
