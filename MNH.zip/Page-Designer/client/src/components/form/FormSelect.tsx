import { useFormContext } from "react-hook-form";
import { cn } from "@/lib/utils";

interface FormSelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  name: string;
  label: string;
  options: { label: string; value: string }[];
  placeholder?: string;
}

export function FormSelect({ name, label, options, placeholder, className, ...props }: FormSelectProps) {
  const { register, formState: { errors } } = useFormContext();
  const error = errors[name]?.message as string | undefined;

  return (
    <div className="space-y-2">
      <label htmlFor={name} className="form-label">
        {label}
        {props.required && <span className="text-destructive ml-1">*</span>}
      </label>
      <select
        id={name}
        {...register(name)}
        className={cn(
          "form-input h-auto py-2.5",
          error && "border-destructive focus-visible:ring-destructive",
          className
        )}
        {...props}
      >
        {placeholder && <option value="">{placeholder}</option>}
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
      {error && <p className="text-xs font-medium text-destructive">{error}</p>}
    </div>
  );
}
