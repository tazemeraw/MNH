import React from "react";
import { motion } from "framer-motion";

interface SectionProps {
  title: string;
  description?: string;
  children: React.ReactNode;
  isActive?: boolean;
}

export function Section({ title, description, children, isActive = true }: SectionProps) {
  if (!isActive) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="bg-card rounded-xl p-6 md:p-8 shadow-sm border border-border/50 mb-8"
    >
      <div className="mb-6 border-b border-border pb-4">
        <h3 className="text-xl font-bold text-foreground font-display">{title}</h3>
        {description && <p className="text-muted-foreground mt-1 text-sm">{description}</p>}
      </div>
      <div className="space-y-6">
        {children}
      </div>
    </motion.div>
  );
}
