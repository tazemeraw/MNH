import { useFormContext } from "react-hook-form";
import { cn } from "@/lib/utils";
import { Check } from "lucide-react";

interface FormCheckboxProps extends React.InputHTMLAttributes<HTMLInputElement> {
  name: string;
  label: string;
}

export function FormCheckbox({ name, label, className, ...props }: FormCheckboxProps) {
  const { register, watch } = useFormContext();
  const checked = watch(name);

  return (
    <div className={cn(
      "flex items-center space-x-3 p-4 rounded-lg border transition-all duration-200 cursor-pointer",
      checked 
        ? "border-primary bg-primary/5 shadow-sm" 
        : "border-input hover:border-primary/50 hover:bg-muted/30",
      className
    )}>
      <div className="relative flex items-center">
        <input
          type="checkbox"
          id={name}
          {...register(name)}
          className="peer h-5 w-5 cursor-pointer appearance-none rounded-md border border-input bg-background transition-all checked:border-primary checked:bg-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
          {...props}
        />
        <Check className="pointer-events-none absolute left-0 top-0 h-5 w-5 text-primary-foreground opacity-0 transition-opacity peer-checked:opacity-100 p-0.5" />
      </div>
      <label htmlFor={name} className="flex-1 cursor-pointer text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
        {label}
      </label>
    </div>
  );
}
